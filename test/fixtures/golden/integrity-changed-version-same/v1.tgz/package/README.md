Inert fixture.
